#include <stdio.h>

int a(int b)
{
    int c, d;
    d = 0;
    c = 10;
    while (c > b)
    {
        d = d + 1;
        c--;
    }
    return (d);
}
