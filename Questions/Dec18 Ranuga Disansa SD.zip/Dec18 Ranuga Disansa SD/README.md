# Test Exam Dec 18 1

### To run the files use the commands below

`gcc {file_name}`
`./a.out`

Ranuga Disansa Belpa Gamage Teen Graduate
